# Johnson Gideon - UI/UX Designer Portfolio

A modern, responsive portfolio website showcasing UI/UX design work. Built with React, TypeScript, Tailwind CSS v4, and Motion for smooth animations.

## 🌟 Features

- **Modern Dark Theme** - Professional dark design with vibrant gradients
- **Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Smooth Animations** - Beautiful interactions powered by Motion
- **Project Showcase** - Direct links to Figma design prototypes
- **Contact Integration** - LinkedIn, email, and phone contact options
- **Performance Optimized** - Fast loading with lazy loading images

## 🚀 Quick Deployment on Netlify

### Method 1: Drag & Drop (Fastest)

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Build the project:**
   ```bash
   npm run build
   ```

3. **Deploy to Netlify:**
   - Go to [netlify.com](https://netlify.com) and sign up/login
   - Click "Add new site" → "Deploy manually"
   - Drag and drop the `dist` folder that was created
   - Your portfolio is now live!

### Method 2: GitHub Integration (Recommended)

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial portfolio commit"
   git remote add origin YOUR_GITHUB_REPO_URL
   git push -u origin main
   ```

2. **Connect to Netlify:**
   - In Netlify dashboard, click "Add new site" → "Import from Git"
   - Connect your GitHub account
   - Select your portfolio repository
   - Build settings are already configured in `netlify.toml`:
     - **Build command:** `npm run build`
     - **Publish directory:** `dist`
   - Click "Deploy site"

3. **Customize your URL:**
   - Change the random URL to something like `johnson-gideon-portfolio`
   - Final URL: `https://johnson-gideon-portfolio.netlify.app`

## 🛠️ Tech Stack

- **React 18** - Modern React with hooks and TypeScript
- **TypeScript** - Type safety and better development experience
- **Tailwind CSS v4** - Latest utility-first CSS framework
- **Motion** - Smooth animations and interactions
- **Vite** - Fast build tool and development server
- **Lucide React** - Beautiful icon library

## 📁 Current File Structure

```
portfolio/
├── App.tsx                 # Main application component
├── main.tsx               # React entry point
├── index.html             # HTML entry point
├── components/            # React components
│   ├── ui/               # Reusable UI components (shadcn)
│   ├── figma/            # Figma-specific components
│   ├── Header.tsx        # Navigation
│   ├── Hero.tsx          # Hero section
│   ├── About.tsx         # About section
│   ├── Skills.tsx        # Skills showcase
│   ├── Projects.tsx      # Portfolio projects
│   ├── Contact.tsx       # Contact form
│   └── Footer.tsx        # Footer with social links
├── styles/
│   └── globals.css       # Global styles and themes
├── lib/
│   └── utils.ts          # Utility functions
├── public/               # Static assets
├── package.json          # Dependencies and scripts
├── vite.config.ts        # Build configuration
├── netlify.toml          # Netlify deployment settings
└── tsconfig.json         # TypeScript configuration
```

## ⚡ Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🎨 Customization

### Update Contact Information
Edit contact details in:
- `components/Contact.tsx` - Contact section and social links
- `components/Footer.tsx` - Footer social links

### Add New Projects
Update the projects array in `components/Projects.tsx` with:
- Project title and description
- Figma prototype URLs
- Technology stack
- Project images (use Unsplash or your own images)

### Modify Colors and Styling
Update the color scheme in `styles/globals.css`:
- CSS custom properties for colors
- Gradient definitions
- Animation keyframes

## 🌐 Portfolio Sections

- **Hero** - Introduction with professional photo and call-to-action
- **About** - Personal background and design philosophy
- **Skills** - Technical skills and design tools
- **Projects** - Featured design projects with Figma links
- **Contact** - Contact form and social media links
- **Footer** - Additional contact information and navigation

## 📱 Contact Information

- **Email:** johnsonabiodun36@gmail.com
- **Phone:** +2347067200899  
- **LinkedIn:** [linkedin.com/in/abiodun-johnson](https://www.linkedin.com/in/abiodun-johnson/)
- **X (Twitter):** [@Johnson34538666](https://x.com/Johnson34538666)
- **Location:** Nigeria 🇳🇬

## 🚀 Featured Projects

1. **Item-7go Redesign** - Food delivery platform UI/UX
2. **GidiHaven Real Estate** - Property listing app design
3. **Fresh Store E-commerce** - Organic food shopping platform
4. **CareCycle Hospital Management** - Healthcare system interface

All projects include direct links to Figma prototypes for detailed viewing.

---

**Built with ❤️ by Johnson Gideon**  
*UI/UX Designer • Nigeria • Available for Freelance Projects*