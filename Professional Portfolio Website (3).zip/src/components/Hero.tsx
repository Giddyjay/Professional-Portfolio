import { ChevronDown, Download, Mail, Sparkles, Palette, Figma } from 'lucide-react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import profileImage from 'figma:asset/85dc4938517288932aaaeffe9fd9eaf6adbc4d80.png';

export function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const floatingIcons = [
    { Icon: Palette, delay: 0, x: 50, y: 30 },
    { Icon: Figma, delay: 1, x: -30, y: 60 },
    { Icon: Sparkles, delay: 2, x: 70, y: -20 },
  ];

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute -top-40 -right-40 w-80 h-80 rounded-full opacity-30"
          style={{ background: 'var(--gradient-primary)' }}
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        <motion.div
          className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full opacity-20"
          style={{ background: 'var(--gradient-secondary)' }}
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      </div>

      {/* Floating icons */}
      {floatingIcons.map((item, index) => (
        <motion.div
          key={index}
          className="absolute text-primary/20"
          style={{ 
            left: `${50 + item.x}%`, 
            top: `${30 + item.y}%` 
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ 
            opacity: [0.2, 0.5, 0.2],
            scale: [1, 1.2, 1],
            y: [-10, 10, -10],
          }}
          transition={{
            delay: item.delay,
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <item.Icon size={40} />
        </motion.div>
      ))}

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            className="text-center lg:text-left order-2 lg:order-1"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-6xl mb-6">
                <motion.span 
                  className="gradient-text block"
                  animate={{ 
                    backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
                  }}
                  transition={{ 
                    duration: 3,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  style={{
                    background: 'linear-gradient(45deg, oklch(0.6 0.25 260), oklch(0.7 0.3 320), oklch(0.75 0.3 180), oklch(0.8 0.4 60))',
                    backgroundSize: '300% 300%',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Johnson Gideon
                </motion.span>
              </h1>
            </motion.div>
            
            <motion.h2 
              className="text-xl md:text-2xl text-muted-foreground mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              <motion.span
                animate={{ color: ['oklch(0.6 0.25 260)', 'oklch(0.7 0.3 320)', 'oklch(0.75 0.3 180)'] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                Junior UI/UX Designer
              </motion.span>
              {' & '}
              <motion.span
                animate={{ color: ['oklch(0.75 0.3 180)', 'oklch(0.8 0.4 60)', 'oklch(0.6 0.25 260)'] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1.5 }}
              >
                Creative Visionary
              </motion.span>
            </motion.h2>
            
            <motion.p 
              className="text-lg text-muted-foreground mb-8 max-w-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.6 }}
            >
              I craft intuitive and visually stunning digital experiences that connect users with brands. 
              Passionate about user-centered design, accessibility, and creating meaningful interactions.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
            >
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  size="lg" 
                  onClick={() => scrollToSection('projects')}
                  className="group relative overflow-hidden pulse-glow"
                  style={{ background: 'var(--gradient-primary)' }}
                >
                  <span className="relative z-10">View My Work</span>
                  <motion.div
                    className="absolute inset-0 bg-white/20"
                    initial={{ x: '-100%' }}
                    whileHover={{ x: '100%' }}
                    transition={{ duration: 0.6 }}
                  />
                  <ChevronDown className="ml-2 h-4 w-4 group-hover:translate-y-1 transition-transform relative z-10" />
                </Button>
              </motion.div>
              
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="group gradient-border hover:shadow-lg transition-all duration-300"
                >
                  <Download className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
                  Download Resume
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
          
          {/* Profile Image Section */}
          <motion.div 
            className="relative order-1 lg:order-2 flex justify-center lg:justify-end"
            initial={{ opacity: 0, x: 50, rotateY: 15 }}
            animate={{ opacity: 1, x: 0, rotateY: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <div className="relative z-10">
              <motion.div
                className="relative"
                whileHover={{ scale: 1.05, y: -10 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                {/* Main profile image */}
                <motion.div
                  className="relative w-80 h-80 lg:w-96 lg:h-96 rounded-full overflow-hidden border-4 border-white/20 shadow-2xl"
                  style={{ 
                    background: 'var(--gradient-primary)',
                    padding: '4px'
                  }}
                  animate={{
                    borderColor: [
                      'rgba(255,255,255,0.2)',
                      'rgba(139,92,246,0.4)',
                      'rgba(59,130,246,0.4)',
                      'rgba(255,255,255,0.2)'
                    ]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <div className="w-full h-full rounded-full overflow-hidden">
                    <img
                      src={profileImage}
                      alt="Johnson Gideon - UI/UX Designer"
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                </motion.div>

                {/* Floating accent elements around the image */}
                <motion.div
                  className="absolute -top-6 -right-6 w-12 h-12 rounded-full"
                  style={{ background: 'var(--gradient-accent)' }}
                  animate={{
                    scale: [1, 1.3, 1],
                    rotate: [0, 180, 360],
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />

                <motion.div
                  className="absolute -bottom-4 -left-4 w-8 h-8 rounded-full"
                  style={{ background: 'var(--gradient-secondary)' }}
                  animate={{
                    scale: [1.2, 1, 1.2],
                    rotate: [360, 180, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />

                <motion.div
                  className="absolute top-1/4 -left-8 w-6 h-6 rounded-full"
                  style={{ background: 'var(--gradient-primary)' }}
                  animate={{
                    y: [-10, 10, -10],
                    opacity: [0.6, 1, 0.6],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />

                {/* Glow effect behind the image */}
                <motion.div
                  className="absolute inset-0 rounded-full -z-10"
                  style={{ 
                    background: 'var(--gradient-primary)',
                    filter: 'blur(20px)',
                  }}
                  animate={{
                    scale: [1, 1.1, 1],
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              </motion.div>

              {/* Professional status indicator */}
              <motion.div
                className="absolute -bottom-6 left-1/2 transform -translate-x-1/2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2, duration: 0.6 }}
              >
                <motion.div
                  className="bg-card/90 backdrop-blur-sm rounded-full px-6 py-3 border border-primary/20 shadow-lg"
                  whileHover={{ scale: 1.05, y: -2 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <div className="flex items-center space-x-2">
                    <motion.div
                      className="w-3 h-3 rounded-full bg-green-500"
                      animate={{
                        scale: [1, 1.2, 1],
                        opacity: [1, 0.7, 1],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    />
                    <span className="text-sm font-medium">Available for Work</span>
                  </div>
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <motion.button 
          onClick={() => scrollToSection('about')}
          className="text-primary hover:text-secondary transition-colors"
          whileHover={{ scale: 1.2 }}
          whileTap={{ scale: 0.9 }}
        >
          <ChevronDown size={24} />
        </motion.button>
      </motion.div>
    </section>
  );
}