import { Mail, MapPin, Phone, Linkedin, Github, Twitter, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { motion } from 'motion/react';

export function Contact() {
  const contactInfo = [
    {
      icon: <Mail className="h-5 w-5" />,
      title: "Email",
      value: "johnsonabiodun36@gmail.com",
      href: "mailto:johnsonabiodun36@gmail.com",
      gradient: 'var(--gradient-primary)',
      color: 'oklch(0.6 0.25 260)'
    },
    {
      icon: <Phone className="h-5 w-5" />,
      title: "Phone",
      value: "+2347067200899",
      href: "tel:+2347067200899",
      gradient: 'var(--gradient-secondary)',
      color: 'oklch(0.75 0.3 180)'
    },
    {
      icon: <MapPin className="h-5 w-5" />,
      title: "Location",
      value: "Nigeria",
      href: "#",
      gradient: 'var(--gradient-accent)',
      color: 'oklch(0.8 0.4 60)'
    }
  ];

  const socialLinks = [
    {
      icon: <Linkedin className="h-5 w-5" />,
      name: "LinkedIn",
      href: "https://www.linkedin.com/in/abiodun-johnson/",
      gradient: 'linear-gradient(135deg, #0077B5 0%, #00A0DC 100%)',
      color: '#0077B5'
    },
    {
      icon: <Github className="h-5 w-5" />,
      name: "GitHub",
      href: "#",
      gradient: 'linear-gradient(135deg, #333 0%, #666 100%)',
      color: '#333'
    },
    {
      icon: <Twitter className="h-5 w-5" />,
      name: "Twitter",
      href: "#",
      gradient: 'linear-gradient(135deg, #1DA1F2 0%, #0084B4 100%)',
      color: '#1DA1F2'
    }
  ];

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section id="contact" className="py-20 relative overflow-hidden">
      {/* Background decorations */}
      <motion.div
        className="absolute top-20 right-0 w-48 h-48 rounded-full opacity-10"
        style={{ background: 'var(--gradient-primary)' }}
        animate={{
          scale: [1, 1.3, 1],
          rotate: [0, 180, 360],
          x: [0, -30, 0],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      <motion.div
        className="absolute bottom-32 left-0 w-32 h-32 rounded-full opacity-15"
        style={{ background: 'var(--gradient-accent)' }}
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
          y: [0, 20, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl mb-4"
            whileHover={{ scale: 1.05 }}
          >
            <span className="gradient-text">Let's Connect</span>
          </motion.h2>
          <motion.p 
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            Have a project in mind or want to collaborate? I'd love to hear from you and discuss how we can create something amazing together.
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid lg:grid-cols-2 gap-12"
        >
          {/* Contact Information */}
          <motion.div variants={itemVariants}>
            <motion.h3 
              className="text-2xl mb-6 gradient-text"
              whileHover={{ scale: 1.02 }}
            >
              Contact Information
            </motion.h3>
            
            <motion.div 
              className="space-y-4 mb-8"
              variants={{
                hidden: {},
                visible: {
                  transition: {
                    staggerChildren: 0.1
                  }
                }
              }}
            >
              {contactInfo.map((info, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  whileHover={{ 
                    x: 10,
                    scale: 1.02,
                    boxShadow: `0 5px 15px ${info.color}20`
                  }}
                  className="flex items-center space-x-4 p-4 rounded-lg bg-card/50 backdrop-blur-sm border border-border/50 hover-lift group"
                >
                  <motion.div 
                    className="text-white p-3 rounded-full"
                    style={{ background: info.gradient }}
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  >
                    {info.icon}
                  </motion.div>
                  <div>
                    <motion.p 
                      className="text-sm text-muted-foreground group-hover:opacity-80"
                    >
                      {info.title}
                    </motion.p>
                    <motion.a 
                      href={info.href}
                      className="hover:opacity-80 transition-opacity"
                      style={{ color: info.color }}
                      whileHover={{ scale: 1.05 }}
                    >
                      {info.value}
                    </motion.a>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            <motion.div variants={itemVariants}>
              <motion.h4 
                className="text-lg mb-4"
                whileHover={{ scale: 1.02 }}
              >
                Follow Me
              </motion.h4>
              <motion.div 
                className="flex space-x-4"
                variants={{
                  hidden: {},
                  visible: {
                    transition: {
                      staggerChildren: 0.1
                    }
                  }
                }}
              >
                {socialLinks.map((social, index) => (
                  <motion.div
                    key={index}
                    variants={itemVariants}
                    whileHover={{ 
                      scale: 1.1, 
                      y: -5,
                      boxShadow: `0 10px 20px ${social.color}30`
                    }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      className="group hover:text-white transition-all duration-300 relative overflow-hidden"
                      asChild
                    >
                      <a 
                        href={social.href} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        aria-label={`Follow Johnson on ${social.name}`}
                      >
                        <motion.div
                          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                          style={{ background: social.gradient }}
                        />
                        <span className="relative z-10 flex items-center">
                          <motion.div
                            whileHover={{ rotate: 360 }}
                            transition={{ duration: 0.6 }}
                          >
                            {social.icon}
                          </motion.div>
                          <span className="ml-2">{social.name}</span>
                        </span>
                      </a>
                    </Button>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div variants={itemVariants}>
            <Card className="gradient-border hover-lift relative overflow-hidden">
              <motion.div
                className="absolute inset-0 opacity-5"
                style={{ background: 'var(--gradient-primary)' }}
                animate={{
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
              
              <CardHeader className="relative z-10">
                <CardTitle className="gradient-text">Send a Message</CardTitle>
              </CardHeader>
              
              <CardContent className="relative z-10">
                <motion.form 
                  onSubmit={handleSubmit} 
                  className="space-y-4"
                  variants={{
                    hidden: {},
                    visible: {
                      transition: {
                        staggerChildren: 0.1
                      }
                    }
                  }}
                >
                  <motion.div 
                    className="grid md:grid-cols-2 gap-4"
                    variants={itemVariants}
                  >
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <motion.div
                        whileFocus={{ scale: 1.02 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <Input 
                          id="name" 
                          placeholder="Your name" 
                          required 
                          className="focus:ring-2 focus:ring-primary/50 transition-all duration-300"
                        />
                      </motion.div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <motion.div
                        whileFocus={{ scale: 1.02 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <Input 
                          id="email" 
                          type="email" 
                          placeholder="your.email@example.com" 
                          required 
                          className="focus:ring-2 focus:ring-primary/50 transition-all duration-300"
                        />
                      </motion.div>
                    </div>
                  </motion.div>
                  
                  <motion.div className="space-y-2" variants={itemVariants}>
                    <Label htmlFor="subject">Subject</Label>
                    <motion.div
                      whileFocus={{ scale: 1.02 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <Input 
                        id="subject" 
                        placeholder="Project collaboration" 
                        required 
                        className="focus:ring-2 focus:ring-primary/50 transition-all duration-300"
                      />
                    </motion.div>
                  </motion.div>
                  
                  <motion.div className="space-y-2" variants={itemVariants}>
                    <Label htmlFor="message">Message</Label>
                    <motion.div
                      whileFocus={{ scale: 1.02 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <Textarea 
                        id="message" 
                        placeholder="Tell me about your project or how we can collaborate..." 
                        className="min-h-[120px] focus:ring-2 focus:ring-primary/50 transition-all duration-300"
                        required 
                      />
                    </motion.div>
                  </motion.div>
                  
                  <motion.div
                    variants={itemVariants}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button 
                      type="submit" 
                      className="w-full relative overflow-hidden group pulse-glow"
                      style={{ background: 'var(--gradient-primary)' }}
                    >
                      <motion.div
                        className="absolute inset-0 bg-white/20"
                        initial={{ x: '-100%' }}
                        whileHover={{ x: '100%' }}
                        transition={{ duration: 0.6 }}
                      />
                      <span className="relative z-10 flex items-center justify-center">
                        <Send className="mr-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        Send Message
                      </span>
                    </Button>
                  </motion.div>
                </motion.form>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}