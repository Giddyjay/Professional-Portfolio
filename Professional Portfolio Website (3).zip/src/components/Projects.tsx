import { ExternalLink, Figma } from "lucide-react";
import { Button } from "./ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import gidiHavenImage from "figma:asset/fe6b7be9aa8199964b41670b37827e3225f39b46.png";
import careCycleImage1 from "figma:asset/0a9ed0b17e5d0ec78957f0fc7662f9fa71f83c1b.png";
import careCycleImage2 from "figma:asset/e5363c0c5f882bcf8cb7d32ee65b4c84222cdc8b.png";
import item7goLaptop from "figma:asset/b4864c784d445739c7d04fa0dd29f1517cd86e18.png";
import item7goMobile from "figma:asset/b64870a9157e57e4cc224e176d0dc0d61a9b819e.png";
import freshStoreMobile from "figma:asset/96176f06009fbfc5a2326a5496913b6a68fe3ed8.png";

export function Projects() {
  const projects = [
    {
      title: "Item-7go Redesign",
      description:
        "Complete UI/UX redesign of Item-7go food delivery platform featuring modern African cuisine ordering interface. Redesigned both web and mobile experiences with improved user flows, authentication screens, and delicious food presentation that celebrates African culinary culture.",
      image: item7goLaptop,
      technologies: [
        "UI Design",
        "UX Research",
        "Figma",
        "User Flow",
        "Mobile Design",
        "Food Delivery UX",
      ],
      figmaUrl:
        "https://www.figma.com/design/jrdPdM0b38wKfTRcF0hRXa/Item-7go--redesign?node-id=0-1&t=VfRioHz8Yr9XfUXf-0",
      gradient: "var(--gradient-primary)",
      accentColor: "oklch(0.7 0.3 260)",
      category: "Platform Redesign",
      additionalImages: [item7goMobile],
    },
    {
      title: "GidiHaven Real Estate Platform",
      description:
        "Comprehensive design system for GidiHaven real estate website and mobile app. Created intuitive property search experience, detailed listing views, and seamless user journey from browsing to booking appointments with modern card-based layouts.",
      image: gidiHavenImage,
      technologies: [
        "Mobile Design",
        "Web Design",
        "Information Architecture",
        "User Journey",
        "Property Listings",
      ],
      figmaUrl:
        "https://www.figma.com/design/oGFCpqx6wMteGmzD7Zjl2Z/Real-estate-website-and-app?node-id=0-1&p=f&t=qbHLMM2ah4X6ffo6-0",
      gradient: "var(--gradient-secondary)",
      accentColor: "oklch(0.8 0.35 180)",
      category: "Real Estate App",
    },
    {
      title: "Fresh Store E-commerce",
      description:
        "Modern e-commerce mobile app for Fresh Store focusing on farm-fresh produce and healthy lifestyle. Features user profiles, fresh product catalogs, social features with recipe sharing, and seamless shopping experience for organic food lovers.",
      image: freshStoreMobile,
      technologies: [
        "E-commerce Design",
        "Mobile UX",
        "Social Features",
        "Product Catalog",
        "Health & Wellness UI",
      ],
      figmaUrl:
        "https://www.figma.com/design/4t1tIJ3WBKOtbj0wmWzsDi/Fresh-Store?node-id=2008-1959&t=dRGaApqcqMKe9bks-0",
      gradient: "var(--gradient-accent)",
      accentColor: "oklch(0.85 0.45 60)",
      category: "E-commerce Platform",
    },
    {
      title: "CareCycle Hospital Management System",
      description:
        "Comprehensive digital health platform designed for healthcare professionals and patients. Features intuitive medication management, prescription uploads, and streamlined healthcare workflows optimized for Nigerian healthcare system.",
      image: careCycleImage2,
      technologies: [
        "Healthcare UX",
        "Mobile Health",
        "Prescription Management",
        "Patient Portal",
        "Medical Interface",
      ],
      figmaUrl:
        "https://www.figma.com/design/NN0GuVhskXOGfNBNX6Na3y/Care-Cycle-Hospital-Management-system?node-id=4-104&p=f&t=759TZAXrJAoL3ZHG-0",
      gradient:
        "linear-gradient(135deg, oklch(0.8 0.35 320) 0%, oklch(0.85 0.4 280) 100%)",
      accentColor: "oklch(0.8 0.35 320)",
      category: "Healthcare System",
      additionalImages: [careCycleImage1],
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const projectVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
  };

  return (
    <section
      id="projects"
      className="py-20 relative overflow-hidden"
    >
      {/* Background decoration */}
      <motion.div
        className="absolute top-32 left-0 w-64 h-64 rounded-full opacity-10"
        style={{ background: "var(--gradient-secondary)" }}
        animate={{
          x: [-50, 50, -50],
          y: [0, -30, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="text-3xl md:text-4xl mb-4"
            whileHover={{ scale: 1.05 }}
          >
            <span className="gradient-text">
              Featured Projects
            </span>
          </motion.h2>
          <motion.p
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            A showcase of my UI/UX design work, demonstrating
            user-centered design principles and creative
            problem-solving
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid lg:grid-cols-2 gap-8"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              variants={projectVariants}
              whileHover={{
                y: -10,
                boxShadow: `0 20px 40px ${project.accentColor}20`,
              }}
              className="group"
            >
              <Card className="overflow-hidden hover-lift relative h-full flex flex-col modern-card border-0">
                {/* Image container with overlay effects */}
                <div className="relative overflow-hidden">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    transition={{
                      duration: 0.6,
                      ease: "easeOut",
                    }}
                  >
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-48 object-cover"
                    />
                  </motion.div>

                  {/* Gradient overlay */}
                  <motion.div
                    className="absolute inset-0 opacity-0 group-hover:opacity-60 transition-opacity duration-300"
                    style={{
                      background: `${project.gradient}`,
                    }}
                  />

                  {/* Action buttons overlay */}
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center space-x-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    initial={{ scale: 0.8 }}
                    whileHover={{ scale: 1 }}
                  >
                    <motion.div
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Button
                        variant="secondary"
                        size="sm"
                        className="bg-background/90 hover:bg-background text-foreground shadow-lg backdrop-blur-sm"
                        onClick={() =>
                          window.open(
                            project.figmaUrl,
                            "_blank",
                          )
                        }
                      >
                        <Figma className="h-4 w-4 mr-2" />
                        View Design
                      </Button>
                    </motion.div>

                    <motion.div
                      whileHover={{ scale: 1.1, rotate: -5 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Button
                        size="sm"
                        className="shadow-lg backdrop-blur-sm"
                        style={{ background: project.gradient }}
                        onClick={() =>
                          window.open(
                            project.figmaUrl,
                            "_blank",
                          )
                        }
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Prototype
                      </Button>
                    </motion.div>
                  </motion.div>

                  {/* Project category indicator */}
                  <motion.div
                    className="absolute top-4 right-4 px-3 py-1 rounded-full text-white shadow-lg text-xs backdrop-blur-sm"
                    style={{
                      background: `${project.gradient}`,
                    }}
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true }}
                    transition={{
                      delay: index * 0.2,
                      duration: 0.6,
                    }}
                  >
                    {project.category}
                  </motion.div>
                </div>

                <CardHeader className="flex-grow">
                  <CardTitle className="flex items-center justify-between">
                    <motion.span
                      whileHover={{ scale: 1.02 }}
                      style={{ color: project.accentColor }}
                    >
                      {project.title}
                    </motion.span>
                  </CardTitle>
                </CardHeader>

                <CardContent className="pt-0">
                  <motion.p
                    className="text-muted-foreground mb-4"
                    initial={{ opacity: 0.8 }}
                    whileHover={{ opacity: 1 }}
                  >
                    {project.description}
                  </motion.p>

                  <motion.div
                    className="flex flex-wrap gap-2 mb-4"
                    variants={{
                      hidden: {},
                      visible: {
                        transition: {
                          staggerChildren: 0.1,
                        },
                      },
                    }}
                  >
                    {project.technologies.map(
                      (tech, techIndex) => (
                        <motion.div
                          key={techIndex}
                          initial={{ opacity: 0, scale: 0.8 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          viewport={{ once: true }}
                          transition={{
                            delay: techIndex * 0.1,
                          }}
                          whileHover={{
                            scale: 1.1,
                            boxShadow: `0 0 10px ${project.accentColor}40`,
                          }}
                        >
                          <Badge
                            variant="outline"
                            className="hover:bg-primary/10 transition-colors cursor-default backdrop-blur-sm"
                            style={{
                              borderColor: `${project.accentColor}40`,
                            }}
                          >
                            {tech}
                          </Badge>
                        </motion.div>
                      ),
                    )}
                  </motion.div>

                  {/* Show additional images preview */}
                  {project.additionalImages && (
                    <motion.div
                      className="mb-4"
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.3 }}
                    >
                      <div className="flex space-x-2 overflow-x-auto pb-2">
                        <motion.div
                          className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border border-border/50"
                          whileHover={{ scale: 1.1 }}
                          transition={{ duration: 0.3 }}
                        >
                          <img
                            src={project.image}
                            alt={`${project.title} main view`}
                            className="w-full h-full object-cover"
                          />
                        </motion.div>
                        {project.additionalImages.map(
                          (img, imgIndex) => (
                            <motion.div
                              key={imgIndex}
                              className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border border-border/50"
                              whileHover={{ scale: 1.1 }}
                              transition={{ duration: 0.3 }}
                            >
                              <img
                                src={img}
                                alt={`${project.title} preview ${imgIndex + 1}`}
                                className="w-full h-full object-cover"
                              />
                            </motion.div>
                          ),
                        )}
                      </div>
                    </motion.div>
                  )}

                  {/* Direct link to Figma */}
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full group hover:bg-primary/10 transition-all duration-300 glass-effect"
                      onClick={() =>
                        window.open(project.figmaUrl, "_blank")
                      }
                    >
                      <Figma className="h-4 w-4 mr-2 group-hover:rotate-12 transition-transform" />
                      Open in Figma
                      <ExternalLink className="h-3 w-3 ml-2 opacity-60" />
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 0.6 }}
        >
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              variant="outline"
              size="lg"
              className="gradient-border hover:shadow-lg transition-all duration-300 group glass-effect"
            >
              <Figma className="mr-2 h-4 w-4 group-hover:rotate-12 transition-transform" />
              View All Projects on Figma
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}