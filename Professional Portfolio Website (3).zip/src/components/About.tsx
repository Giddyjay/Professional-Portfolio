import { Palette, Users, Zap, MapPin, Mail, Phone } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { motion } from 'motion/react';
import profileImage from 'figma:asset/85dc4938517288932aaaeffe9fd9eaf6adbc4d80.png';

export function About() {
  const features = [
    {
      icon: <Palette className="h-6 w-6" />,
      title: "Creative Design",
      description: "Crafting visually appealing interfaces with attention to aesthetics, typography, and visual hierarchy.",
      gradient: 'var(--gradient-primary)',
      delay: 0
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "User-Centered",
      description: "Designing with empathy, focusing on user needs, behaviors, and creating inclusive experiences.",
      gradient: 'var(--gradient-secondary)',
      delay: 0.2
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Problem Solving",
      description: "Translating complex problems into simple, intuitive solutions that enhance user satisfaction.",
      gradient: 'var(--gradient-accent)',
      delay: 0.4
    }
  ];

  const personalInfo = [
    { icon: <MapPin className="h-4 w-4" />, label: "Location", value: "Nigeria" },
    { icon: <Mail className="h-4 w-4" />, label: "Email", value: "johnsonabiodun36@gmail.com" },
    { icon: <Phone className="h-4 w-4" />, label: "Phone", value: "+2347067200899" }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section id="about" className="py-20 relative overflow-hidden">
      {/* Background decoration */}
      <motion.div
        className="absolute top-20 right-10 w-32 h-32 rounded-full opacity-20"
        style={{ background: 'var(--gradient-primary)' }}
        animate={{
          scale: [1, 1.3, 1],
          rotate: [0, 360],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl mb-4"
            whileHover={{ scale: 1.05 }}
          >
            <span className="gradient-text">About Me</span>
          </motion.h2>
          <motion.p 
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            I'm a passionate junior UI/UX designer with a keen eye for detail and a love for creating 
            meaningful digital experiences.
          </motion.p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Profile Image Section */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <motion.div
              whileHover={{ scale: 1.02, rotateY: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="relative"
            >
              {/* Profile image with artistic frame */}
              <div className="relative">
                <motion.div
                  className="relative w-full max-w-sm mx-auto"
                  whileHover={{ y: -10 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div 
                    className="relative rounded-2xl overflow-hidden p-1"
                    style={{ background: 'var(--gradient-primary)' }}
                  >
                    <div className="rounded-xl overflow-hidden bg-background">
                      <img
                        src={profileImage}
                        alt="Johnson Gideon - UI/UX Designer"
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  </div>
                  
                  {/* Floating decorative elements */}
                  <motion.div
                    className="absolute -top-4 -right-4 w-8 h-8 rounded-full"
                    style={{ background: 'var(--gradient-accent)' }}
                    animate={{
                      scale: [1, 1.2, 1],
                      rotate: [0, 180, 360],
                    }}
                    transition={{
                      duration: 6,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                  
                  <motion.div
                    className="absolute -bottom-4 -left-4 w-6 h-6 rounded-full"
                    style={{ background: 'var(--gradient-secondary)' }}
                    animate={{
                      scale: [1.2, 1, 1.2],
                      y: [-5, 5, -5],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                </motion.div>

                {/* Personal info cards */}
                <motion.div
                  className="mt-6 space-y-3"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.5, duration: 0.6 }}
                >
                  {personalInfo.map((info, index) => (
                    <motion.div
                      key={index}
                      className="flex items-center space-x-3 bg-card/50 backdrop-blur-sm rounded-lg p-3 border border-border/50"
                      whileHover={{ x: 10, scale: 1.02 }}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.7 + index * 0.1, duration: 0.4 }}
                    >
                      <motion.div
                        className="p-2 rounded-full text-white"
                        style={{ background: 'var(--gradient-primary)' }}
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                      >
                        {info.icon}
                      </motion.div>
                      <div>
                        <p className="text-xs text-muted-foreground">{info.label}</p>
                        <p className="text-sm font-medium">{info.value}</p>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
          
          {/* About content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.h3 
              className="text-2xl mb-6 gradient-text"
              whileHover={{ scale: 1.02 }}
            >
              My Design Journey
            </motion.h3>
            
            <motion.div className="space-y-6">
              {[
                "Starting with a curiosity for digital aesthetics, I've grown into a designer who values both form and function. My journey began with understanding color theory and typography, evolving into comprehensive user experience design.",
                "I believe great design is invisible - it should feel natural and intuitive to users. My approach combines research, creativity, and iteration to create designs that not only look beautiful but solve real problems.",
                "When I'm not designing, you'll find me exploring the latest design trends, reading about psychology in UX, or sketching ideas for future projects. I'm constantly learning and growing in this ever-evolving field."
              ].map((text, index) => (
                <motion.p 
                  key={index}
                  className="text-muted-foreground"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4 + index * 0.2, duration: 0.6 }}
                  whileHover={{ x: 10 }}
                >
                  {text}
                </motion.p>
              ))}
            </motion.div>

            {/* Additional personal touch */}
            <motion.div
              className="mt-8 p-6 rounded-xl border border-primary/20 bg-gradient-to-r from-primary/5 to-secondary/5"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8, duration: 0.6 }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              <motion.h4 
                className="font-medium mb-2 gradient-text"
                whileHover={{ scale: 1.05 }}
              >
                Based in Nigeria 🇳🇬
              </motion.h4>
              <p className="text-sm text-muted-foreground">
                Available for freelance projects and full-time opportunities. 
                Let's create something amazing together!
              </p>
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-8"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ 
                scale: 1.05,
                y: -10,
                boxShadow: 'var(--glow-primary)'
              }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Card className="text-center gradient-border hover-lift relative overflow-hidden group">
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300"
                  style={{ background: feature.gradient }}
                />
                
                <CardContent className="pt-6 relative z-10">
                  <motion.div 
                    className="mb-4 flex justify-center"
                    whileHover={{ rotate: 360, scale: 1.2 }}
                    transition={{ duration: 0.6 }}
                  >
                    <div 
                      className="p-3 rounded-full text-white"
                      style={{ background: feature.gradient }}
                    >
                      {feature.icon}
                    </div>
                  </motion.div>
                  
                  <motion.h4 
                    className="mb-3"
                    whileHover={{ scale: 1.05 }}
                  >
                    {feature.title}
                  </motion.h4>
                  
                  <motion.p 
                    className="text-muted-foreground"
                    initial={{ opacity: 0.8 }}
                    whileHover={{ opacity: 1 }}
                  >
                    {feature.description}
                  </motion.p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}