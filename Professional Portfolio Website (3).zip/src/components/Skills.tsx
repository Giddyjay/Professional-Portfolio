import { Badge } from './ui/badge';
import { motion } from 'motion/react';

export function Skills() {
  const skillCategories = [
    {
      title: "Design Tools",
      skills: ["Figma", "Adobe XD", "Sketch", "Adobe Photoshop", "Adobe Illustrator", "InVision", "Principle", "Framer"],
      gradient: 'var(--gradient-primary)',
      color: 'oklch(0.6 0.25 260)'
    },
    {
      title: "UX Research & Strategy",
      skills: ["User Research", "Personas", "User Journey Mapping", "Wireframing", "Information Architecture", "Usability Testing", "A/B Testing"],
      gradient: 'var(--gradient-secondary)',
      color: 'oklch(0.75 0.3 180)'
    },
    {
      title: "Design Systems & Visual",
      skills: ["Design Systems", "Style Guides", "Typography", "Color Theory", "Layout Design", "Icon Design", "Branding"],
      gradient: 'var(--gradient-accent)',
      color: 'oklch(0.8 0.4 60)'
    },
    {
      title: "Prototyping & Development",
      skills: ["Interactive Prototypes", "HTML/CSS", "Basic JavaScript", "Responsive Design", "Accessibility", "Design Handoff"],
      gradient: 'linear-gradient(135deg, oklch(0.7 0.3 320) 0%, oklch(0.8 0.35 280) 100%)',
      color: 'oklch(0.7 0.3 320)'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const categoryVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const skillVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.4
      }
    }
  };

  return (
    <section id="skills" className="py-20 relative overflow-hidden">
      {/* Background decorations */}
      <motion.div
        className="absolute top-10 left-10 w-40 h-40 rounded-full opacity-10"
        style={{ background: 'var(--gradient-accent)' }}
        animate={{
          scale: [1, 1.4, 1],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      <motion.div
        className="absolute bottom-20 right-20 w-28 h-28 rounded-full opacity-15"
        style={{ background: 'var(--gradient-primary)' }}
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl mb-4"
            whileHover={{ scale: 1.05 }}
          >
            <span className="gradient-text">Skills & Expertise</span>
          </motion.h2>
          <motion.p 
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            A comprehensive toolkit for creating exceptional user experiences and beautiful interfaces
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-8"
        >
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={categoryIndex}
              variants={categoryVariants}
              whileHover={{ 
                scale: 1.02,
                boxShadow: `0 0 30px ${category.color}30`
              }}
              className="relative group"
            >
              <div className="bg-card rounded-lg p-6 border border-border relative overflow-hidden hover-lift">
                {/* Animated background */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-500"
                  style={{ background: category.gradient }}
                />

                {/* Category title with animated icon */}
                <div className="flex items-center mb-4 relative z-10">
                  <motion.div
                    className="w-4 h-4 rounded-full mr-3"
                    style={{ background: category.gradient }}
                    animate={{
                      scale: [1, 1.2, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: categoryIndex * 0.5
                    }}
                  />
                  <motion.h3 
                    className="text-xl"
                    style={{ color: category.color }}
                    whileHover={{ scale: 1.05 }}
                  >
                    {category.title}
                  </motion.h3>
                </div>

                {/* Skills grid */}
                <motion.div 
                  className="flex flex-wrap gap-2 relative z-10"
                  variants={{
                    hidden: {},
                    visible: {
                      transition: {
                        staggerChildren: 0.1
                      }
                    }
                  }}
                >
                  {category.skills.map((skill, skillIndex) => (
                    <motion.div
                      key={skillIndex}
                      variants={skillVariants}
                      whileHover={{ 
                        scale: 1.1,
                        y: -5,
                        boxShadow: `0 5px 15px ${category.color}40`
                      }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Badge 
                        variant="secondary" 
                        className="cursor-pointer transition-all duration-300 hover:text-white relative overflow-hidden group/badge"
                        style={{
                          borderColor: `${category.color}40`,
                        }}
                      >
                        <motion.div
                          className="absolute inset-0 opacity-0 group-hover/badge:opacity-100 transition-opacity duration-300"
                          style={{ background: category.gradient }}
                        />
                        <span className="relative z-10">{skill}</span>
                      </Badge>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Animated experience level visualization */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center space-x-4 bg-card/50 backdrop-blur-sm rounded-full px-6 py-3 border border-primary/20"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-sm text-muted-foreground">Experience Level:</span>
            <div className="flex space-x-2">
              {[1, 2, 3, 4].map((level) => (
                <motion.div
                  key={level}
                  className="w-3 h-3 rounded-full"
                  style={{ background: 'var(--gradient-primary)' }}
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: level * 0.1, duration: 0.3 }}
                  animate={{
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: level * 0.2
                  }}
                />
              ))}
              <motion.div
                className="w-3 h-3 rounded-full bg-muted"
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5, duration: 0.3 }}
              />
            </div>
            <span className="text-sm">Growing</span>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}