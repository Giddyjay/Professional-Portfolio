import { Heart, Palette, Coffee, Linkedin, Mail, Phone, X } from 'lucide-react';
import { motion } from 'motion/react';

export function Footer() {
  const socialLinks = [
    {
      name: 'LinkedIn',
      href: 'https://www.linkedin.com/in/abiodun-johnson/',
      icon: <Linkedin className="h-4 w-4" />,
      color: '#0077B5'
    },
    {
      name: 'X (Twitter)',
      href: 'https://x.com/Johnson34538666',
      icon: <X className="h-4 w-4" />,
      color: '#000000'
    },
    {
      name: 'Email',
      href: 'mailto:johnsonabiodun36@gmail.com',
      icon: <Mail className="h-4 w-4" />,
      color: '#EA4335'
    },
    {
      name: 'Phone',
      href: 'tel:+2347067200899',
      icon: <Phone className="h-4 w-4" />,
      color: '#34A853'
    }
  ];

  return (
    <motion.footer 
      className="relative overflow-hidden"
      style={{ background: 'var(--gradient-primary)' }}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      {/* Animated background elements */}
      <motion.div
        className="absolute top-0 left-0 w-32 h-32 rounded-full opacity-20 bg-white"
        animate={{
          scale: [1, 1.5, 1],
          x: [-20, 20, -20],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      <motion.div
        className="absolute bottom-0 right-0 w-24 h-24 rounded-full opacity-15 bg-white"
        animate={{
          scale: [1.2, 1, 1.2],
          y: [-10, 10, -10],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      <div className="container mx-auto px-4 py-8 relative z-10">
        <motion.div 
          className="text-center text-primary-foreground"
          variants={{
            hidden: {},
            visible: {
              transition: {
                staggerChildren: 0.2
              }
            }
          }}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {/* Social Links */}
          <motion.div
            className="flex justify-center space-x-6 mb-6"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0 }
            }}
          >
            {socialLinks.map((social, index) => (
              <motion.a
                key={`${social.name}-${index}`}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 px-3 py-2 rounded-full transition-all duration-300 backdrop-blur-sm"
                whileHover={{ 
                  scale: 1.1, 
                  y: -3,
                  backgroundColor: 'rgba(255,255,255,0.25)'
                }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                aria-label={`Connect with Johnson on ${social.name}`}
              >
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  {social.icon}
                </motion.div>
                <span className="text-sm hidden sm:inline">{social.name}</span>
              </motion.a>
            ))}
          </motion.div>

          <motion.div
            className="flex items-center justify-center space-x-2 mb-4"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0 }
            }}
          >
            <span>© 2025 Johnson Gideon. Designed with</span>
            
            <motion.div
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [0, 10, -10, 0]
              }}
              transition={{ 
                duration: 1.5,
                repeat: Infinity,
                repeatDelay: 2
              }}
            >
              <Heart className="h-4 w-4 text-red-300 fill-current" />
            </motion.div>
            
            <span>and lots of</span>
            
            <motion.div
              animate={{ 
                y: [0, -5, 0],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1
              }}
            >
              <Coffee className="h-4 w-4 text-amber-300" />
            </motion.div>
          </motion.div>
          
          <motion.div
            className="flex items-center justify-center space-x-2 mb-6"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0 }
            }}
          >
            <span className="text-primary-foreground/80">Crafted with</span>
            
            <motion.div
              whileHover={{ 
                scale: 1.2,
                rotate: 360,
                color: '#FF6B6B'
              }}
              transition={{ duration: 0.6 }}
            >
              <Palette className="h-4 w-4" />
            </motion.div>
            
            <motion.span
              whileHover={{ scale: 1.05 }}
              className="text-primary-foreground/80 hover:text-white transition-colors cursor-default"
            >
              Figma, React, and Creative Passion
            </motion.span>
          </motion.div>
          
          {/* Professional tagline */}
          <motion.div
            className="text-primary-foreground/60 text-sm"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0 }
            }}
          >
            <motion.p
              whileHover={{ scale: 1.02 }}
              className="cursor-default"
            >
              UI/UX Designer • Nigeria 🇳🇬 • Available for Freelance Projects
            </motion.p>
          </motion.div>
          
          {/* Quick navigation */}
          <motion.div
            className="mt-6 flex justify-center space-x-8"
            variants={{
              hidden: { opacity: 0 },
              visible: { opacity: 1 }
            }}
          >
            {[
              { name: 'About', href: '#about' },
              { name: 'Projects', href: '#projects' },
              { name: 'Contact', href: '#contact' }
            ].map((item, index) => (
              <motion.a
                key={item.name}
                href={item.href}
                className="text-sm text-primary-foreground/70 hover:text-white transition-colors relative"
                whileHover={{ scale: 1.1, y: -2 }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                {item.name}
                <motion.div
                  className="absolute -bottom-1 left-0 h-0.5 bg-white"
                  initial={{ width: 0 }}
                  whileHover={{ width: '100%' }}
                  transition={{ duration: 0.3 }}
                />
              </motion.a>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </motion.footer>
  );
}